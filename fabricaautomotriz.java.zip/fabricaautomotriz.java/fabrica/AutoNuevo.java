package fabrica;

public class AutoNuevo extends Vehiculo{

    public AutoNuevo(String color, String marca, String modelo, int precio, String marcaR, int potencia) {
        super(color, marca, modelo, precio, marcaR, potencia);
        
    }
    
    public AutoNuevo(String color, String marca, String modelo, String marcaR, int potencia) {
        super(color, marca, modelo, marcaR, potencia);
        
    }

    



}
