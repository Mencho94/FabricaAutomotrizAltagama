package fabrica;

public class AutoClasico extends Vehiculo{

    public AutoClasico(String color, String marca, String modelo, int precio, String marcaR, int potencia) {
        super(color, marca, modelo, precio, marcaR, potencia);
        
    }
    
    public AutoClasico(String color, String marca, String modelo, int precio) {
        super(color, marca, modelo, precio);
        
    }

    public AutoClasico(String color, String marca, String modelo) {
        super(color, marca, modelo);
        
    }

}
