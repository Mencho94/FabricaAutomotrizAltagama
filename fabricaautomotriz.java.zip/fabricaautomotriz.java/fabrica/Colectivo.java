package fabrica;

public final class Colectivo extends Vehiculo{

    public Colectivo(String color, String marca, String modelo, int precio, String marcaR, int potencia) {
        super(color, marca, modelo, precio, marcaR, potencia);
        
    }

    public Colectivo(String color, String marca, String modelo, int precio) {
        super(color, marca, modelo, precio);
        
    }
    
    public Colectivo(String color, String marca, String modelo) {
        super(color, marca, modelo);
        
    }
 

}
