package test;

import fabrica.AutoClasico;
import fabrica.AutoNuevo;
import fabrica.Colectivo;

public class TestVehiculo{
    public static void main(String[] args) {
        
        AutoClasico autoClasico =  new AutoClasico("negro", "chevrolet", "camaro(69)");
        System.out.println(autoClasico);
        
        AutoClasico autoClasico2 = new AutoClasico("negro", "ford", "mustang(69)", 150000000);
        System.out.println(autoClasico2);

        AutoClasico autoClasico3 = new AutoClasico("negro", "dodge", "charger(70)", 150000000, "sony", 50);
        System.out.println(autoClasico3);

        AutoNuevo autoNuevo = new AutoNuevo("negro", "ferrari", "F460", "Pionner", 100);
        System.out.println(autoNuevo);

        AutoNuevo autoNuevo2 = new AutoNuevo("negro", "lamborghini", "huracan", 150000000, "panasonic", 100);
        System.out.println(autoNuevo2);

        Colectivo colectivo = new Colectivo("blanco", "mercedes benz", "piso bajo");
        System.out.println(colectivo);

        Colectivo colectivo2 = new Colectivo("blanco", "mercedes benz", "piso semi bajo", 15000000);
        System.out.println(colectivo2);

        Colectivo colectivo3 = new Colectivo("blanco", "mercedes benz", "piso super bajo", 15000000, "philips", 50);
        System.out.println(colectivo3);
    
    }
    
}



